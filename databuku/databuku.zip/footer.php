</div>
    <footer>
        <hr>
        <div class="container text-center">
            <small>
                <p>Site designed to be used</p>
                <p>
                    &copy; 2020 | CRUD Information System by Rizki Aliffiyyanto
                </p>
            </small>
        </div>
    </footer>
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/datatables-demo.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/dataTables.bootstrap4.js"></script>
    <script src="js/ajax.js"></script>
</body>
</html>